package Database;

class ADMIN extends STUDENT {

    private String Login;
    private String Password;

    ADMIN() {
        this.Login = " ";
        this.Password = " ";
    }

    ADMIN(String login, String password) {
        this.Login = login;
        this.Password = password;
    }

    //Adminitrator account mutators.
    //*****
    private void setLogin(String login) {
        this.Login = login;
    }

    private void setPassword(String password) {
        this.Password = password;
    }
    //*****

    //Student account and profile mutators.
    //*****
    private void setSTUDENTlogin(String login) {
        super.Login = login;
    }

    private void setSTUDENTpassword(String password) {
        super.Login = password;
    }

    private void setSTUDENTnameFirst(String name) {
        super.First = name;
    }

    private void setSTUDENTnameLast(String name) {
        super.Last = name;
    }

    private void setSTUDENTid(String id) {
        super.ID = id;
    }
    //*****

    //Course mutators.
    //*****    
    public void setTitle(int index, String title) {
        super.Courses.get(index).Title = title;
    }

    public void setExam1(int index, double exam1) {
        this.Courses.get(index).Exam1 = exam1;
    }

    public void setExam2(int index, double exam2) {
        this.Courses.get(index).Exam2 = exam2;
    }

    public void setExam3(int index, double exam3) {
        this.Courses.get(index).Exam3 = exam3;
    }

    public void setCreditHours(int index, int creditHours) {
        if (creditHours <= 4 && creditHours > 0) {
            super.Courses.get(index).CreditHours = creditHours;
        } else {
            System.out.print("Invalid input, number of Credit Hours for a course"
                    + " must be between 1 - 4");
        }
    }
    //*****
}
